<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.html");
    exit;
}

include "conexion.php";
$query = "SELECT * FROM notificaciones ORDER BY fecha DESC";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notificaciones</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>
    <h2>Notificaciones</h2>
    <ul>
        <?php while ($row = $result->fetch_assoc()): ?>
            <li><?php echo $row['mensaje'] . " — " . $row['fecha']; ?></li>
        <?php endwhile; ?>
    </ul>
    <a href="index.php">Volver al panel</a>
</body>
</html>
