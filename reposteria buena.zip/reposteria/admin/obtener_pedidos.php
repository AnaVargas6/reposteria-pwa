<?php
header('Content-Type: application/json; charset=utf-8');
include 'conexion.php';

$sql = "SELECT * FROM pedidos";
$result = $conn->query($sql);
$pedidos = [];

if ($result && $result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    $pedidos[] = $row;
  }
}

echo json_encode($pedidos);
$conn->close();
?>
