<?php
header('Content-Type: application/json; charset=utf-8');
include 'conexion.php';

$sql = "SELECT id, usuario, password FROM usuarios";
$result = $conn->query($sql);

$usuarios = [];
if ($result && $result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    $usuarios[] = $row;
  }
}

echo json_encode($usuarios);
$conn->close();
?>
