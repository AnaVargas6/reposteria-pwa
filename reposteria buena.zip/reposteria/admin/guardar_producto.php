<?php
header('Content-Type: application/json; charset=utf-8');
include 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  echo json_encode(['success' => false, 'mensaje' => 'Método no permitido']);
  exit;
}

$nombre       = $_POST['nombreProducto']      ?? '';
$precio       = $_POST['precioProducto']      ?? 0;
$ingredientes = $_POST['ingredientesProducto']?? '';

// Sanitizar
$nombre       = $conn->real_escape_string($nombre);
$ingredientes = $conn->real_escape_string($ingredientes);
$precio       = is_numeric($precio) ? (float)$precio : 0;

// Insert con o sin imagen
if (isset($_FILES['imagenProducto']) && $_FILES['imagenProducto']['error'] === UPLOAD_ERR_OK) {
  $imagenData = file_get_contents($_FILES['imagenProducto']['tmp_name']);
  $imagenEsc  = $conn->real_escape_string($imagenData);
  $sql = "INSERT INTO productos (nombreProducto, precio, ingredientes, imagen)
          VALUES ('$nombre', '$precio', '$ingredientes', '$imagenEsc')";
} else {
  $sql = "INSERT INTO productos (nombreProducto, precio, ingredientes)
          VALUES ('$nombre', '$precio', '$ingredientes')";
}

if ($conn->query($sql) === TRUE) {
  // ✅ Enviar notificación tras el INSERT
  require_once __DIR__ . '/send-notification.php';

  $precioFmt = number_format($precio, 2); // 2 decimales
  $notify = enviarNotificacionNuevoProducto(
    $conn,
    "Nuevo producto agregado 🎂",
    $nombre . " ahora disponible por \$" . $precioFmt, // OJO: \$ para imprimir el signo $
    "/reposteria/index.html" // Cambia si tu base no es /reposteria
  );

  echo json_encode([
    'success' => true,
    'mensaje' => 'Producto guardado correctamente',
    'id'      => $conn->insert_id,
    'notify'  => $notify      // Para que veas okCount/http en Network
  ]);
} else {
  echo json_encode(['success' => false, 'mensaje' => $conn->error]);
}

$conn->close();
