<?php
header('Content-Type: application/json; charset=utf-8');
include 'conexion.php';

$sql = "SELECT * FROM ingredientes";
$result = $conn->query($sql);
$ingredientes = [];

if ($result && $result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    $ingredientes[] = $row;
  }
}

echo json_encode($ingredientes);
$conn->close();
?>
