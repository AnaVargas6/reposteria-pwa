<?php
header('Content-Type: application/json; charset=utf-8');
include 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['idProducto'] ?? '';
    $nombre = $_POST['nombreProducto'] ?? '';
    $precio = $_POST['precioProducto'] ?? 0;
    $ingredientes = $_POST['ingredientesProducto'] ?? '';

    if ($id === '') {
        echo json_encode(['success' => false, 'mensaje' => 'Falta idProducto']);
        exit;
    }

    $id = (int)$id;
    $nombre = $conn->real_escape_string($nombre);
    $ingredientes = $conn->real_escape_string($ingredientes);
    $precio = is_numeric($precio) ? $precio : 0;

    if (isset($_FILES['imagenProducto']) && $_FILES['imagenProducto']['error'] === UPLOAD_ERR_OK) {
        $imagenData = file_get_contents($_FILES['imagenProducto']['tmp_name']);
        $imagenEsc = $conn->real_escape_string($imagenData);
        $sql = "UPDATE productos
                SET nombreProducto='$nombre', precio='$precio', ingredientes='$ingredientes', imagen='$imagenEsc'
                WHERE idProducto='$id'";
    } else {
        $sql = "UPDATE productos
                SET nombreProducto='$nombre', precio='$precio', ingredientes='$ingredientes'
                WHERE idProducto='$id'";
    }

    if ($conn->query($sql) === TRUE) {
        echo json_encode(['success' => true, 'mensaje' => 'Producto actualizado correctamente']);
    } else {
        echo json_encode(['success' => false, 'mensaje' => $conn->error]);
    }
    $conn->close();
} else {
    echo json_encode(['success' => false, 'mensaje' => 'Método no permitido']);
}
