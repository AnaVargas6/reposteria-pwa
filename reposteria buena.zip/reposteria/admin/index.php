<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.html");
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Administrativo</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>
    <header>
        <h1>Panel Administrativo</h1>
        <p>Bienvenido, <?php echo $_SESSION['usuario']; ?></p>
        <a href="logout.php">Cerrar sesión</a>
    </header>

    <nav>
        <ul>
            <li><a href="notificaciones.php">Notificaciones</a></li>
            <li><a href="crud_ingredientes.php">CRUD Ingredientes</a></li>
        </ul>
    </nav>

    <main>
        <h2>Dashboard</h2>
        <p>Este es el panel administrativo donde puedes gestionar tu sitio.</p>
    </main>
</body>
</html>
