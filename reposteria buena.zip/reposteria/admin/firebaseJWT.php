<?php
class JWT {
    public static function encode($payload, $key, $alg) {
        $header = ['alg' => $alg, 'typ' => 'JWT'];
        $segments = [
            self::urlsafeB64Encode(json_encode($header)),
            self::urlsafeB64Encode(json_encode($payload))
        ];
        $signing_input = implode('.', $segments);
        openssl_sign($signing_input, $signature, $key, OPENSSL_ALGO_SHA256);
        $segments[] = self::urlsafeB64Encode($signature);
        return implode('.', $segments);
    }
    private static function urlsafeB64Encode($data) {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }
}
