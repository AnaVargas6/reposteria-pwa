<?php
header('Content-Type: application/json; charset=utf-8');
include 'conexion.php';

$id = $_POST['idIngrediente'] ?? '';

if ($id === '') {
  echo json_encode(['success' => false, 'mensaje' => 'Falta ID']);
  exit;
}

$sql = "DELETE FROM ingredientes WHERE idIngrediente='$id'";

if ($conn->query($sql) === TRUE) {
  echo json_encode(['success' => true, 'mensaje' => 'Ingrediente borrado correctamente']);
} else {
  echo json_encode(['success' => false, 'mensaje' => $conn->error]);
}

$conn->close();
?>
