<?php
header('Content-Type: application/json; charset=utf-8');
ini_set('display_errors', 1);
error_reporting(E_ALL);

require __DIR__ . '/send-notification.php';

$out = enviarNotificacionNuevoProducto(
  $conn,
  "Prueba FCM",
  "Si ves esta notificación, todo está OK ✅",
  "/reposteria/index.html"
);

echo json_encode($out, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
