<?php
header('Content-Type: application/json; charset=utf-8');
include 'conexion.php';

$id = $_POST['idIngrediente'] ?? '';
$nombre = $_POST['nombreIngrediente'] ?? '';
$existencias = $_POST['existencias'] ?? '';

if ($id === '' || $nombre === '') {
  echo json_encode(['success' => false, 'mensaje' => 'Datos incompletos']);
  exit;
}

$sql = "UPDATE ingredientes
        SET nombreIngrediente='$nombre', existencias='$existencias'
        WHERE idIngrediente='$id'";

if ($conn->query($sql) === TRUE) {
  echo json_encode(['success' => true, 'mensaje' => 'Ingrediente editado correctamente']);
} else {
  echo json_encode(['success' => false, 'mensaje' => $conn->error]);
}

$conn->close();
?>
