<?php
header('Content-Type: application/json; charset=utf-8');
include 'conexion.php';

$cliente = $_POST['cliente'] ?? '';
$detalle = $_POST['detalle'] ?? '';
$total = $_POST['total'] ?? 0;

if ($cliente === '' || $detalle === '') {
  echo json_encode(['success' => false, 'mensaje' => 'Datos incompletos']);
  exit;
}

$sql = "INSERT INTO pedidos (cliente, detalle, total)
        VALUES ('$cliente', '$detalle', '$total')";

if ($conn->query($sql) === TRUE) {
  echo json_encode(['success' => true, 'mensaje' => 'Pedido agregado', 'id' => $conn->insert_id]);
} else {
  echo json_encode(['success' => false, 'mensaje' => $conn->error]);
}

$conn->close();
?>
