<?php
header('Content-Type: application/json; charset=utf-8');
include 'conexion.php';

if (empty($_POST['nombreIngrediente']) || !isset($_POST['existencias'])) {
  echo json_encode(['success' => false, 'mensaje' => 'Datos incompletos']);
  exit;
}

$nombre = $_POST['nombreIngrediente'];
$existencias = $_POST['existencias'];

$sql = "INSERT INTO ingredientes (nombreIngrediente, existencias)
        VALUES ('$nombre', '$existencias')";

if ($conn->query($sql) === TRUE) {
  echo json_encode(['success' => true, 'mensaje' => 'Ingrediente agregado', 'id' => $conn->insert_id]);
} else {
  echo json_encode(['success' => false, 'mensaje' => $conn->error]);
}

$conn->close();
?>
