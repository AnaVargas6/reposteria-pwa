<?php
header('Content-Type: application/json; charset=utf-8');
include 'conexion.php';

$input = json_decode(file_get_contents('php://input'), true);
$token = isset($input['token']) ? trim($input['token']) : '';

if (!$token) {
  http_response_code(400);
  echo json_encode(['ok' => false, 'error' => 'Token vacío']);
  exit;
}

$stmt = $conn->prepare("INSERT IGNORE INTO fcm_tokens (token) VALUES (?)");
$stmt->bind_param("s", $token);
$ok = $stmt->execute();
$stmt->close();

echo json_encode(['ok' => $ok]);
