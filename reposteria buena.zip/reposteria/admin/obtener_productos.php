<?php
header('Content-Type: application/json; charset=utf-8');
include "conexion.php";

$sql = "SELECT idProducto, nombreProducto, precio, ingredientes, imagen FROM productos";
$result = $conn->query($sql);
$productos = [];

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        if (isset($row['imagen']) && !is_null($row['imagen'])) {
            $row['imagen'] = "data:image/jpeg;base64," . base64_encode($row['imagen']);
        } else {
            $row['imagen'] = null;
        }
        $productos[] = $row;
    }
}

echo json_encode($productos);
$conn->close();
