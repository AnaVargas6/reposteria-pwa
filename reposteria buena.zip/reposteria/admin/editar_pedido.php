<?php
header('Content-Type: application/json; charset=utf-8');
include 'conexion.php';

$id = $_POST['idPedido'] ?? '';
$cliente = $_POST['cliente'] ?? '';
$detalle = $_POST['detalle'] ?? '';
$total = $_POST['total'] ?? 0;

if ($id === '' || $cliente === '' || $detalle === '') {
  echo json_encode(['success' => false, 'mensaje' => 'Datos incompletos']);
  exit;
}

$sql = "UPDATE pedidos
        SET cliente='$cliente', detalle='$detalle', total='$total'
        WHERE idPedido='$id'";

if ($conn->query($sql) === TRUE) {
  echo json_encode(['success' => true, 'mensaje' => 'Pedido editado correctamente']);
} else {
  echo json_encode(['success' => false, 'mensaje' => $conn->error]);
}

$conn->close();
?>
