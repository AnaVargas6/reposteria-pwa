<?php
header('Content-Type: application/json; charset=utf-8');
include 'conexion.php';

$usuario = $_POST['usuario'] ?? '';
$password = $_POST['password'] ?? '';

if ($usuario === '' || $password === '') {
  echo json_encode(['success' => false, 'mensaje' => 'Campos vacíos']);
  exit;
}

$sql = "SELECT id FROM usuarios WHERE usuario='$usuario' AND password='$password'";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
  echo json_encode(['success' => true, 'mensaje' => 'Inicio de sesión exitoso']);
} else {
  echo json_encode(['success' => false, 'mensaje' => 'Credenciales inválidas']);
}

$conn->close();
?>
