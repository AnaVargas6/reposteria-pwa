<?php
include 'conexion.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $idProducto=$_POST['idProducto'];
  $stmt=$conn->prepare('DELETE FROM productos WHERE idProducto=?');
  $stmt->bind_param('i',$idProducto);
  if($stmt->execute()){ echo json_encode(['success'=>true,'mensaje'=>'Producto eliminado correctamente']); }
  else { echo json_encode(['success'=>false,'mensaje'=>$stmt->error]); }
  $stmt->close(); $conn->close();
}?>