<?php
header('Content-Type: application/json; charset=utf-8');
include 'conexion.php';

$id = $_POST['idPedido'] ?? '';

if ($id === '') {
  echo json_encode(['success' => false, 'mensaje' => 'Falta ID']);
  exit;
}

$sql = "DELETE FROM pedidos WHERE idPedido='$id'";

if ($conn->query($sql) === TRUE) {
  echo json_encode(['success' => true, 'mensaje' => 'Pedido eliminado correctamente']);
} else {
  echo json_encode(['success' => false, 'mensaje' => $conn->error]);
}

$conn->close();
?>
