<?php
// /reposteria/admin/send-notification.php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require __DIR__ . '/firebaseJWT.php';
include 'conexion.php';

/**
 * Envía notificación FCM (HTTP v1) a todos los tokens de fcm_tokens.
 * Devuelve ['okCount'=>N, 'results'=>[ {http,resp,err,token}, ... ], 'error'=>?]
 */
function enviarNotificacionNuevoProducto(mysqli $conn, string $titulo, string $mensaje, string $url = "/reposteria/index.html") {
    // 1) Tokens
    $tokens = [];
    $q = $conn->query("SELECT token FROM fcm_tokens");
    if ($q) {
        while ($r = $q->fetch_assoc()) {
            $tokens[] = $r['token'];
        }
        $q->close();
    }
    if (count($tokens) === 0) {
        return ['okCount' => 0, 'results' => [], 'error' => 'Sin tokens en fcm_tokens'];
    }

    // 2) Credenciales de servicio
    $saPath = __DIR__ . '/firebase-key.json';
    if (!file_exists($saPath)) {
        return ['okCount' => 0, 'results' => [], 'error' => 'No existe firebase-key.json'];
    }
    $sa = json_decode(file_get_contents($saPath), true);
    if (!$sa || empty($sa['client_email']) || empty($sa['private_key']) || empty($sa['project_id'])) {
        return ['okCount' => 0, 'results' => [], 'error' => 'firebase-key.json inválido/incompleto'];
    }

    // 3) JWT -> Access Token (scope recomendado para FCM v1)
    $now = time();
    $jwtPayload = [
        "iss"   => $sa['client_email'],
        "sub"   => $sa['client_email'],
        "aud"   => "https://oauth2.googleapis.com/token",
        "iat"   => $now,
        "exp"   => $now + 3600,
        "scope" => "https://www.googleapis.com/auth/firebase.messaging"
    ];
    $jwt = JWT::encode($jwtPayload, $sa['private_key'], 'RS256');

    $ch = curl_init("https://oauth2.googleapis.com/token");
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query([
            'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
            'assertion'  => $jwt,
        ]),
        CURLOPT_RETURNTRANSFER => true
    ]);
    $tokenResp = curl_exec($ch);
    $curlErr   = curl_error($ch);
    curl_close($ch);

    if ($curlErr) {
        return ['okCount' => 0, 'results' => [], 'error' => "CURL token: $curlErr"];
    }
    $tokenData = json_decode($tokenResp, true);
    if (empty($tokenData['access_token'])) {
        return ['okCount' => 0, 'results' => [], 'error' => 'Sin access_token', 'raw' => $tokenData];
    }

    $accessToken = $tokenData['access_token'];
    $projectId   = $sa['project_id'];
    $endpoint    = "https://fcm.googleapis.com/v1/projects/" . $projectId . "/messages:send";
    $headers     = [
        "Authorization: Bearer " . $accessToken,
        "Content-Type: application/json"
    ];

    // 4) Enviar uno por uno (HTTP v1 no acepta registration_ids)
    $okCount = 0;
    $results = [];

    foreach ($tokens as $t) {
        // Construimos el cuerpo con webpush y data (sin comentarios dentro)
        $body = [
            "message" => [
                "token"   => $t,
                "webpush" => [
                    "notification" => [
                        "title" => $titulo,
                        "body"  => $mensaje,
                        "icon"  => "/reposteria/images/icon-192.png"
                    ],
                    "fcm_options" => [
                        "link" => $url
                    ]
                ],
                "data" => [
                    "title" => $titulo,
                    "body"  => $mensaje,
                    "url"   => $url,
                    "icon"  => "/reposteria/images/icon-192.png"
                ]
            ]
        ];

        $ch = curl_init($endpoint);
        curl_setopt_array($ch, [
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => json_encode($body),
            CURLOPT_RETURNTRANSFER => true
        ]);
        $resp = curl_exec($ch);
        $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);

        if ($http >= 200 && $http < 300 && !$err) {
            $okCount++;
        }

        $results[] = [
            'token' => $t,
            'http'  => $http,
            'resp'  => $resp,
            'err'   => $err
        ];
    }

    return ['okCount' => $okCount, 'results' => $results];
}
